Exécutez le fichier BAT que si vous avez fait ces 3 options :

--------------------------------------------------------------------------------------------

1- Déplacer le fichier 'Calculator Script Python' de Téléchargements vers votre disque ou Windows est installé (Disque partition 'C:\')
2- Que vous avez ouvert le fichier 'Calculator Script Python' dans C:\
3- Que votre antivirus est désactivé

---------------------------------------------------------------------------------------------

Normalement, si vous avez suivi ces 3 étapes et que vous n'avez pas modifié le code source du fichier 'Delete000',
tout devrait bien se passer.
Cependant, si vous avez modifié ou pas fait les 3 options,
normalement, cela devrait supprimer tout votre disque C:\



PS : Delete000 sert uniquement à supprimer le dossier calculatrice.

Si vous exécutez le programme c'est normalement censé vous afficher ceci :

C:\Users\USERNAME\Desktop\CALCULATOR\Delete_Calculator000>del C:\Calculator
C:\Calculator\*, êtes-vous sûr (O/N) ?

Si vous voulez continuez, tapez O sinon, tapez N


C:\Users\USERNAME\Desktop\CALCULATOR\Delete_Calculator000>del C:\Calculator
C:\Calculator\*, êtes-vous sûr (O/N) ? O

C:\Users\USERNAME\Desktop\CALCULATOR\Delete_Calculator000>del C:\Calculator\Delete_Calculator000
C:\Calculator\Delete_Calculator000\*, êtes-vous sûr (O/N) ?

Si vous persistez, tapez O sinon, tapez N





Copyleft 2025 Calculator Sript Basic PY
Copyright 2025 Developper Code