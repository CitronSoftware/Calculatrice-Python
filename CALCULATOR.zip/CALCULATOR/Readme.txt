Merci d'avoir téléchargé le fichier.
Pour éviter tout BUG, Merci de déplacer le dossier CALCULATOR
vers votre disque local (partition C:\)
et d'ouvrir le fichier dans C:\





Merci encore une fois.



